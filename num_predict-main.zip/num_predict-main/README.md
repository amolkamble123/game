# num_predict
Number Prediction Game

This code includes two main functions called ProgramA and ProgramB.

First, generate_first_num() function generates a number between 0 and 9 and adds it to the NumberStoreA queue.

Then, Program_B also expects data from the NumberScoreB queue. If data comes from the queue, it makes 5 number predictions and if one of the
predictions is correct, it gets 1 point to PointStore variable.

This process will continue continuously for both programs.

